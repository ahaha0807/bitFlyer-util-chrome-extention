/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 2);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */,
/* 1 */,
/* 2 */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(3);


/***/ }),
/* 3 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var input_size = document.querySelector('#priceForm .input-group .input_size');
var input_price = document.querySelector('#priceForm .input-group .input_price');

var values = __webpack_require__(4);
var template = __webpack_require__(5);

input_size.addEventListener('input', function () {
  deleteOldElement();

  var expectedJpy = Math.floor(input_size.value * input_price.value);

  rendering(expectedJpy);
});

input_price.addEventListener('input', function () {
  deleteOldElement();

  var expectedJpy = Math.floor(input_size.value * input_price.value);

  rendering(expectedJpy);
});

var deleteOldElement = function deleteOldElement() {
  try {
    var oldElement = document.getElementById(values.DATA_BOX_ID);
    oldElement.parentNode.removeChild(oldElement);
  } catch (e) {
    //
  }
};

var rendering = function rendering(expectedJpy) {
  var row = document.querySelectorAll('#priceForm tr')[0];

  var label = template.createLabel();
  var div = template.createValue(expectedJpy);

  var td = document.createElement('td');
  td.id = values.DATA_BOX_ID;
  td.setAttribute('colspan', 1);
  td.appendChild(label);
  td.appendChild(div);

  row.appendChild(td);
};

/***/ }),
/* 4 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var DATA_BOX_ID = exports.DATA_BOX_ID = 'expected-jpy';
var DATA_LABEL_CLASSNAME = exports.DATA_LABEL_CLASSNAME = 'expected-jpy-label';
var DATA_LABEL_TEXT = exports.DATA_LABEL_TEXT = '日本円参考額';
var DATA_VALUE_CLASSNAME = exports.DATA_VALUE_CLASSNAME = 'expected-jpy-value';

/***/ }),
/* 5 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


Object.defineProperty(exports, "__esModule", {
  value: true
});
var values = __webpack_require__(4);

var createLabel = exports.createLabel = function createLabel() {
  var div = document.createElement('div');
  div.className = values.DATA_LABEL_CLASSNAME;
  div.innerHTML = values.DATA_LABEL_TEXT;
  return div;
};

var createValue = exports.createValue = function createValue(expectedJpy) {
  var div = document.createElement('div');
  div.className = values.DATA_VALUE_CLASSNAME;
  div.innerHTML = expectedJpy + ' JPY';
  return div;
};

/***/ })
/******/ ]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAgYjRlNDMxM2I3MDI0Mjg1MjkyNjkiLCJ3ZWJwYWNrOi8vLy4vYXBwL3NjcmlwdHMvY29udGVudHNjcmlwdC5qcyIsIndlYnBhY2s6Ly8vLi9hcHAvc2NyaXB0cy9hc3NldHMvdmFsdWVzLmpzIiwid2VicGFjazovLy8uL2FwcC9zY3JpcHRzL2xpYi90ZW1wbGF0ZS5qcyJdLCJuYW1lcyI6WyJpbnB1dF9zaXplIiwiZG9jdW1lbnQiLCJxdWVyeVNlbGVjdG9yIiwiaW5wdXRfcHJpY2UiLCJ2YWx1ZXMiLCJyZXF1aXJlIiwidGVtcGxhdGUiLCJhZGRFdmVudExpc3RlbmVyIiwiZGVsZXRlT2xkRWxlbWVudCIsImV4cGVjdGVkSnB5IiwiTWF0aCIsImZsb29yIiwidmFsdWUiLCJyZW5kZXJpbmciLCJvbGRFbGVtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJEQVRBX0JPWF9JRCIsInBhcmVudE5vZGUiLCJyZW1vdmVDaGlsZCIsImUiLCJyb3ciLCJxdWVyeVNlbGVjdG9yQWxsIiwibGFiZWwiLCJjcmVhdGVMYWJlbCIsImRpdiIsImNyZWF0ZVZhbHVlIiwidGQiLCJjcmVhdGVFbGVtZW50IiwiaWQiLCJzZXRBdHRyaWJ1dGUiLCJhcHBlbmRDaGlsZCIsIkRBVEFfTEFCRUxfQ0xBU1NOQU1FIiwiREFUQV9MQUJFTF9URVhUIiwiREFUQV9WQUxVRV9DTEFTU05BTUUiLCJjbGFzc05hbWUiLCJpbm5lckhUTUwiXSwibWFwcGluZ3MiOiI7QUFBQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTs7O0FBR0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsYUFBSztBQUNMO0FBQ0E7O0FBRUE7QUFDQTtBQUNBO0FBQ0EsbUNBQTJCLDBCQUEwQixFQUFFO0FBQ3ZELHlDQUFpQyxlQUFlO0FBQ2hEO0FBQ0E7QUFDQTs7QUFFQTtBQUNBLDhEQUFzRCwrREFBK0Q7O0FBRXJIO0FBQ0E7O0FBRUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdEQSxJQUFJQSxhQUFhQyxTQUFTQyxhQUFULENBQXVCLHFDQUF2QixDQUFqQjtBQUNBLElBQUlDLGNBQWNGLFNBQVNDLGFBQVQsQ0FBdUIsc0NBQXZCLENBQWxCOztBQUVBLElBQUlFLFNBQVMsbUJBQUFDLENBQVEsQ0FBUixDQUFiO0FBQ0EsSUFBSUMsV0FBVyxtQkFBQUQsQ0FBUSxDQUFSLENBQWY7O0FBRUFMLFdBQVdPLGdCQUFYLENBQTRCLE9BQTVCLEVBQXFDLFlBQU07QUFDekNDOztBQUVBLE1BQUlDLGNBQWNDLEtBQUtDLEtBQUwsQ0FBV1gsV0FBV1ksS0FBWCxHQUFtQlQsWUFBWVMsS0FBMUMsQ0FBbEI7O0FBRUFDLFlBQVVKLFdBQVY7QUFDRCxDQU5EOztBQVFBTixZQUFZSSxnQkFBWixDQUE2QixPQUE3QixFQUFzQyxZQUFNO0FBQzFDQzs7QUFFQSxNQUFJQyxjQUFjQyxLQUFLQyxLQUFMLENBQVdYLFdBQVdZLEtBQVgsR0FBbUJULFlBQVlTLEtBQTFDLENBQWxCOztBQUVBQyxZQUFVSixXQUFWO0FBQ0QsQ0FORDs7QUFRQSxJQUFNRCxtQkFBbUIsU0FBbkJBLGdCQUFtQixHQUFNO0FBQzdCLE1BQUk7QUFDRixRQUFJTSxhQUFhYixTQUFTYyxjQUFULENBQXdCWCxPQUFPWSxXQUEvQixDQUFqQjtBQUNBRixlQUFXRyxVQUFYLENBQXNCQyxXQUF0QixDQUFrQ0osVUFBbEM7QUFDRCxHQUhELENBR0UsT0FBT0ssQ0FBUCxFQUFVO0FBQ1Y7QUFDRDtBQUNGLENBUEQ7O0FBU0EsSUFBTU4sWUFBWSxTQUFaQSxTQUFZLENBQUNKLFdBQUQsRUFBaUI7QUFDakMsTUFBSVcsTUFBTW5CLFNBQVNvQixnQkFBVCxDQUEwQixlQUExQixFQUEyQyxDQUEzQyxDQUFWOztBQUVBLE1BQUlDLFFBQVFoQixTQUFTaUIsV0FBVCxFQUFaO0FBQ0EsTUFBSUMsTUFBTWxCLFNBQVNtQixXQUFULENBQXFCaEIsV0FBckIsQ0FBVjs7QUFFQSxNQUFJaUIsS0FBS3pCLFNBQVMwQixhQUFULENBQXVCLElBQXZCLENBQVQ7QUFDQUQsS0FBR0UsRUFBSCxHQUFReEIsT0FBT1ksV0FBZjtBQUNBVSxLQUFHRyxZQUFILENBQWdCLFNBQWhCLEVBQTJCLENBQTNCO0FBQ0FILEtBQUdJLFdBQUgsQ0FBZVIsS0FBZjtBQUNBSSxLQUFHSSxXQUFILENBQWVOLEdBQWY7O0FBRUFKLE1BQUlVLFdBQUosQ0FBZ0JKLEVBQWhCO0FBQ0QsQ0FiRCxDOzs7Ozs7Ozs7Ozs7QUMvQk8sSUFBTVYsb0NBQWMsY0FBcEI7QUFDQSxJQUFNZSxzREFBdUIsb0JBQTdCO0FBQ0EsSUFBTUMsNENBQWtCLFFBQXhCO0FBQ0EsSUFBTUMsc0RBQXVCLG9CQUE3QixDOzs7Ozs7Ozs7Ozs7QUNIUCxJQUFJN0IsU0FBUyxtQkFBQUMsQ0FBUSxDQUFSLENBQWI7O0FBRU8sSUFBSWtCLG9DQUFjLFNBQWRBLFdBQWMsR0FBTTtBQUM3QixNQUFJQyxNQUFNdkIsU0FBUzBCLGFBQVQsQ0FBdUIsS0FBdkIsQ0FBVjtBQUNBSCxNQUFJVSxTQUFKLEdBQWdCOUIsT0FBTzJCLG9CQUF2QjtBQUNBUCxNQUFJVyxTQUFKLEdBQWdCL0IsT0FBTzRCLGVBQXZCO0FBQ0EsU0FBT1IsR0FBUDtBQUNELENBTE07O0FBT0EsSUFBSUMsb0NBQWMsU0FBZEEsV0FBYyxjQUFlO0FBQ3RDLE1BQUlELE1BQU12QixTQUFTMEIsYUFBVCxDQUF1QixLQUF2QixDQUFWO0FBQ0FILE1BQUlVLFNBQUosR0FBZ0I5QixPQUFPNkIsb0JBQXZCO0FBQ0FULE1BQUlXLFNBQUosR0FBZ0IxQixjQUFjLE1BQTlCO0FBQ0EsU0FBT2UsR0FBUDtBQUNELENBTE0sQyIsImZpbGUiOiJjb250ZW50c2NyaXB0LmpzIiwic291cmNlc0NvbnRlbnQiOlsiIFx0Ly8gVGhlIG1vZHVsZSBjYWNoZVxuIFx0dmFyIGluc3RhbGxlZE1vZHVsZXMgPSB7fTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0bW9kdWxlc1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cbiBcdFx0Ly8gRmxhZyB0aGUgbW9kdWxlIGFzIGxvYWRlZFxuIFx0XHRtb2R1bGUubCA9IHRydWU7XG5cbiBcdFx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiBcdFx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuIFx0fVxuXG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlcyBvYmplY3QgKF9fd2VicGFja19tb2R1bGVzX18pXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm0gPSBtb2R1bGVzO1xuXG4gXHQvLyBleHBvc2UgdGhlIG1vZHVsZSBjYWNoZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5jID0gaW5zdGFsbGVkTW9kdWxlcztcblxuIFx0Ly8gZGVmaW5lIGdldHRlciBmdW5jdGlvbiBmb3IgaGFybW9ueSBleHBvcnRzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQgPSBmdW5jdGlvbihleHBvcnRzLCBuYW1lLCBnZXR0ZXIpIHtcbiBcdFx0aWYoIV9fd2VicGFja19yZXF1aXJlX18ubyhleHBvcnRzLCBuYW1lKSkge1xuIFx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBuYW1lLCB7XG4gXHRcdFx0XHRjb25maWd1cmFibGU6IGZhbHNlLFxuIFx0XHRcdFx0ZW51bWVyYWJsZTogdHJ1ZSxcbiBcdFx0XHRcdGdldDogZ2V0dGVyXG4gXHRcdFx0fSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSBmdW5jdGlvbihtb2R1bGUpIHtcbiBcdFx0dmFyIGdldHRlciA9IG1vZHVsZSAmJiBtb2R1bGUuX19lc01vZHVsZSA/XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0RGVmYXVsdCgpIHsgcmV0dXJuIG1vZHVsZVsnZGVmYXVsdCddOyB9IDpcbiBcdFx0XHRmdW5jdGlvbiBnZXRNb2R1bGVFeHBvcnRzKCkgeyByZXR1cm4gbW9kdWxlOyB9O1xuIFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCAnYScsIGdldHRlcik7XG4gXHRcdHJldHVybiBnZXR0ZXI7XG4gXHR9O1xuXG4gXHQvLyBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGxcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubyA9IGZ1bmN0aW9uKG9iamVjdCwgcHJvcGVydHkpIHsgcmV0dXJuIE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmplY3QsIHByb3BlcnR5KTsgfTtcblxuIFx0Ly8gX193ZWJwYWNrX3B1YmxpY19wYXRoX19cbiBcdF9fd2VicGFja19yZXF1aXJlX18ucCA9IFwiXCI7XG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMik7XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gd2VicGFjay9ib290c3RyYXAgYjRlNDMxM2I3MDI0Mjg1MjkyNjkiLCJsZXQgaW5wdXRfc2l6ZSA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNwcmljZUZvcm0gLmlucHV0LWdyb3VwIC5pbnB1dF9zaXplJyk7XG5sZXQgaW5wdXRfcHJpY2UgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcjcHJpY2VGb3JtIC5pbnB1dC1ncm91cCAuaW5wdXRfcHJpY2UnKTtcblxubGV0IHZhbHVlcyA9IHJlcXVpcmUoJy4vYXNzZXRzL3ZhbHVlcycpXG5sZXQgdGVtcGxhdGUgPSByZXF1aXJlKCcuL2xpYi90ZW1wbGF0ZScpXG5cbmlucHV0X3NpemUuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGRlbGV0ZU9sZEVsZW1lbnQoKVxuXG4gIGxldCBleHBlY3RlZEpweSA9IE1hdGguZmxvb3IoaW5wdXRfc2l6ZS52YWx1ZSAqIGlucHV0X3ByaWNlLnZhbHVlKSAgXG5cbiAgcmVuZGVyaW5nKGV4cGVjdGVkSnB5KVxufSlcblxuaW5wdXRfcHJpY2UuYWRkRXZlbnRMaXN0ZW5lcignaW5wdXQnLCAoKSA9PiB7XG4gIGRlbGV0ZU9sZEVsZW1lbnQoKVxuXG4gIGxldCBleHBlY3RlZEpweSA9IE1hdGguZmxvb3IoaW5wdXRfc2l6ZS52YWx1ZSAqIGlucHV0X3ByaWNlLnZhbHVlKSAgXG5cbiAgcmVuZGVyaW5nKGV4cGVjdGVkSnB5KVxufSlcblxuY29uc3QgZGVsZXRlT2xkRWxlbWVudCA9ICgpID0+IHtcbiAgdHJ5IHtcbiAgICBsZXQgb2xkRWxlbWVudCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKHZhbHVlcy5EQVRBX0JPWF9JRClcbiAgICBvbGRFbGVtZW50LnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQob2xkRWxlbWVudCk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvL1xuICB9XG59XG5cbmNvbnN0IHJlbmRlcmluZyA9IChleHBlY3RlZEpweSkgPT4ge1xuICBsZXQgcm93ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnI3ByaWNlRm9ybSB0cicpWzBdXG5cbiAgbGV0IGxhYmVsID0gdGVtcGxhdGUuY3JlYXRlTGFiZWwoKTtcbiAgbGV0IGRpdiA9IHRlbXBsYXRlLmNyZWF0ZVZhbHVlKGV4cGVjdGVkSnB5KVxuXG4gIGxldCB0ZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3RkJylcbiAgdGQuaWQgPSB2YWx1ZXMuREFUQV9CT1hfSURcbiAgdGQuc2V0QXR0cmlidXRlKCdjb2xzcGFuJywgMSlcbiAgdGQuYXBwZW5kQ2hpbGQobGFiZWwpXG4gIHRkLmFwcGVuZENoaWxkKGRpdilcblxuICByb3cuYXBwZW5kQ2hpbGQodGQpXG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9hcHAvc2NyaXB0cy9jb250ZW50c2NyaXB0LmpzIiwiZXhwb3J0IGNvbnN0IERBVEFfQk9YX0lEID0gJ2V4cGVjdGVkLWpweSdcbmV4cG9ydCBjb25zdCBEQVRBX0xBQkVMX0NMQVNTTkFNRSA9ICdleHBlY3RlZC1qcHktbGFiZWwnXG5leHBvcnQgY29uc3QgREFUQV9MQUJFTF9URVhUID0gJ+aXpeacrOWGhuWPguiAg+mhjSdcbmV4cG9ydCBjb25zdCBEQVRBX1ZBTFVFX0NMQVNTTkFNRSA9ICdleHBlY3RlZC1qcHktdmFsdWUnXG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9hcHAvc2NyaXB0cy9hc3NldHMvdmFsdWVzLmpzIiwibGV0IHZhbHVlcyA9IHJlcXVpcmUoJy4uL2Fzc2V0cy92YWx1ZXMnKVxuXG5leHBvcnQgbGV0IGNyZWF0ZUxhYmVsID0gKCkgPT4ge1xuICBsZXQgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2JylcbiAgZGl2LmNsYXNzTmFtZSA9IHZhbHVlcy5EQVRBX0xBQkVMX0NMQVNTTkFNRVxuICBkaXYuaW5uZXJIVE1MID0gdmFsdWVzLkRBVEFfTEFCRUxfVEVYVFxuICByZXR1cm4gZGl2XG59XG5cbmV4cG9ydCBsZXQgY3JlYXRlVmFsdWUgPSBleHBlY3RlZEpweSA9PiB7XG4gIGxldCBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuICBkaXYuY2xhc3NOYW1lID0gdmFsdWVzLkRBVEFfVkFMVUVfQ0xBU1NOQU1FXG4gIGRpdi5pbm5lckhUTUwgPSBleHBlY3RlZEpweSArICcgSlBZJ1xuICByZXR1cm4gZGl2XG59XG5cblxuXG4vLyBXRUJQQUNLIEZPT1RFUiAvL1xuLy8gLi9hcHAvc2NyaXB0cy9saWIvdGVtcGxhdGUuanMiXSwic291cmNlUm9vdCI6IiJ9